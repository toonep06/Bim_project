import React from 'react';
import Projects from './Projects';

function Content() {
  return (
    <div className="container-fluid">
      <Projects/>
    </div>
  );
}

export default Content;
